import datetime


class Clock:

    def get_time(self):
        return datetime.datetime.now()
