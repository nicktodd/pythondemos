To run the tests, use
'''
python -m unittest -v
'''

You do not need to install any libraries as this uses built in capabilities